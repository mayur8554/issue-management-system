package com.issue.issue_managenment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IssueManagenmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(IssueManagenmentApplication.class, args);
	}

}
