package com.issue.issue_managenment.Exception;

public class UserNotFoundException extends RuntimeException {

	public UserNotFoundException(String message) {
		super(message);

	}

}
