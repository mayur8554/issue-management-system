
package com.issue.issue_managenment.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.issue.issue_managenment.DTO.AssignIssueRequest;
import com.issue.issue_managenment.DTO.UpdateDetailDto;
import com.issue.issue_managenment.DTO.UpdateStatusDto;
import com.issue.issue_managenment.Entity.Issue;
import com.issue.issue_managenment.Entity.Role;
import com.issue.issue_managenment.Entity.Status;
import com.issue.issue_managenment.Entity.User;
import com.issue.issue_managenment.Exception.IssueNotFoundException;
import com.issue.issue_managenment.Exception.UnauthorizedIssueManagerException;
import com.issue.issue_managenment.Exception.UserNotFoundException;
import com.issue.issue_managenment.Repo.IssueRepo;
import com.issue.issue_managenment.Repo.UserRepo;
import com.issue.issue_managenment.Service.IssueService;

import jakarta.transaction.Transactional;

@RestController
@RequestMapping("/issue")
@CrossOrigin(origins = "http://localhost:4200")
public class IssueController {

	@Autowired
	IssueRepo issueRepo;

	@Autowired
	IssueService issueService;
	@Autowired
	UserRepo userRepo;

	@PostMapping("/add")
	public ResponseEntity<?> addIssue(@RequestBody Issue issue, @RequestParam int userId) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
		try {
			Issue savedIssue = issueService.addIssue(issue, user);
			return ResponseEntity.ok(savedIssue);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

//////////////////////////////////////////////////////////////
	@GetMapping("/viewUserIssue")
	public ResponseEntity<List<Issue>> getUserIssues(@RequestParam int userId) {

		List<Issue> issues = issueService.getUserOwnIssues(userId);

		return ResponseEntity.ok(issues);
	}

/////////////////////////////////////////////////////////////
	@GetMapping("/view")
	public ResponseEntity<?> getAllIssue(@RequestParam int userId) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
		List<Issue> issue = issueService.getAllIssue(user);
		if (issue.isEmpty()) {
			return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No issues available");
		}
		return ResponseEntity.ok(issue);
	}

/////////////////////////////////////////
	@GetMapping("/filterStatus")
	public ResponseEntity<List<Issue>> filterIssueByStatus(@RequestParam Status status, @RequestParam int userId) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
		List<Issue> issue = issueService.filterIssueByStatus(status, user);
		return ResponseEntity.ok(issue);

	}

	@GetMapping("/filterPriority")
	public ResponseEntity<List<Issue>> filterIssueByPriority(@RequestParam com.issue.issue_managenment.Entity.Priority priority,
			@RequestParam int userId) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
		List<Issue> issue = issueService.filterIssueByPriority(priority, user);
		return ResponseEntity.ok(issue);

	}

////////////////////////////////////////////////////////////////////
	@PutMapping("/updateDetails")
	public ResponseEntity<Issue> updateDetails(@RequestParam int issueId, @RequestParam int userId,
			@RequestBody UpdateDetailDto dto) {

		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));

		return ResponseEntity.ok(issueService.updateDetails(issueId, user, dto));
	}

////////////////////////////////////////////////////////////////////////////////////////////
	@PutMapping("/updateStatus")
	public ResponseEntity<Issue> updateStatus(@RequestParam int issueId, @RequestParam int userId,
			@RequestBody UpdateStatusDto dto) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));
		return ResponseEntity.ok(issueService.updateStatus(issueId, user, dto));
	}
	///////////////////////////////////////////////////////////

	@PostMapping("/assign")
	public ResponseEntity<?> assignIssue(@RequestBody AssignIssueRequest request) {
		try {
			Issue updatedIssue = issueService.assignIssue(request.getManagerId(), request.getSolverId(),
					request.getIssueId());
			return ResponseEntity.ok(updatedIssue);
		} catch (UnauthorizedIssueManagerException e) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN).body(e.getMessage());
		} catch (RuntimeException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	////////////////////////////////////////////////

	@GetMapping("/solverIssue")
	public ResponseEntity<List<Issue>> getIssuesBySolverName(@RequestParam String assignee) {

		return ResponseEntity.ok(issueService.getIssuesBySolverName(assignee));
	}
/////////////////////////////////////////////////////////////////////

	@DeleteMapping("/delete")
	public ResponseEntity<String> deleteIssue(@RequestParam int issueId, @RequestParam int userId) {
		User user = userRepo.findById(userId).orElseThrow(() -> new UserNotFoundException("User not found"));

		String message = issueService.deleteIssue(issueId, user);
		return ResponseEntity.ok(message);
	}

}
