package com.issue.issue_managenment.Entity;

public enum Priority {
	LOW,
	MEDIUM,
	HIGH	
}
