package com.issue.issue_managenment.Exception;


public class IssueNotFoundException extends RuntimeException{

	public IssueNotFoundException(String message) {
		super(message);
	}
	
	

}
