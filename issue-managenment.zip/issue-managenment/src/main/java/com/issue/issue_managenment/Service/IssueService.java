package com.issue.issue_managenment.Service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.issue.issue_managenment.DTO.UpdateDetailDto;
import com.issue.issue_managenment.DTO.UpdateStatusDto;
import com.issue.issue_managenment.Entity.Issue;
import com.issue.issue_managenment.Entity.Priority;
import com.issue.issue_managenment.Entity.Role;
import com.issue.issue_managenment.Entity.Status;
import com.issue.issue_managenment.Entity.User;
import com.issue.issue_managenment.Exception.IssueNotFoundException;
import com.issue.issue_managenment.Exception.UnauthorizedIssueManagerException;
import com.issue.issue_managenment.Exception.UnauthorizedIssueRaiserException;
import com.issue.issue_managenment.Exception.UnauthorizedIssueSolverException;
import com.issue.issue_managenment.Exception.UserNotFoundException;
import com.issue.issue_managenment.Repo.IssueRepo;
import com.issue.issue_managenment.Repo.UserRepo;

import jakarta.transaction.Transactional;

@Service
public class IssueService {

	@Autowired
	IssueRepo issueRepo;

	@Autowired
	UserRepo userRepo;

	public Issue addIssue(Issue issue, User user) {
		if (user.getRole() != Role.ISSUE_RAISER) {
			throw new UnauthorizedIssueRaiserException("Only users with ISSUE_RAISER role can add issues");
		}
		issue.setUser(user);
		return issueRepo.save(issue);
	}

//////////////////////////////////////////////////
	public Issue getIssue(int issueId) {
		Issue existingissue = issueRepo.findByIssueId(issueId);
		if (existingissue == null) {
			throw new IssueNotFoundException("Issue Not Found" + issueId);
		}
		return existingissue;
	}

/////////////////////////////////////////////////////////////
	public List<Issue> getUserOwnIssues(int userId) {

		List<Issue> issues = issueRepo.findByUserId(userId);

		if (issues.isEmpty()) {
			throw new IssueNotFoundException("No issues found for this user");
		}

		return issues;
	}

//////////////////////////////////////////////////////
	public List<Issue> getAllIssue(User user) {
		if (user.getRole() != Role.ISSUE_MANAGER) {
			throw new UnauthorizedIssueManagerException("Only users with ISSUE_MANAGER role can add issues");
		}
		return issueRepo.findAll();
	}
////////////////////////////////////////////////////

	@Transactional
	public Issue assignIssue(int managerId, int solverId, int issueId) {

		User manager = userRepo.findById(managerId).orElseThrow(() -> new RuntimeException("Manager not found"));

		if (manager.getRole() != Role.ISSUE_MANAGER) {
			throw new UnauthorizedIssueManagerException("Only ISSUE_MANAGER can assign issues");
		}

		User solver = userRepo.findById(solverId).orElseThrow(() -> new UserNotFoundException("Solver not found"));

		Issue issue = issueRepo.findById(issueId).orElseThrow(() -> new IssueNotFoundException("Issue not found"));

		// Use solver email as assignee value so the solver dashboard can
		// reliably load only issues assigned to the logged‑in solver.
		issue.setAssignee(solver.getEmail());

		return issueRepo.save(issue);
	}

/////////////////////////////////////////////////////////////////////////////////////////
	public List<Issue> filterIssueByStatus(Status status, User user) {
		if (user.getRole() != Role.ISSUE_MANAGER) {
			throw new UnauthorizedIssueManagerException("Only users with ISSUE_MANAGER role can add issues");
		}
		List<Issue> issues = issueRepo.findByStatus(status);
		if (issues.isEmpty()) {
			throw new IssueNotFoundException("No issues found with status " + status);
		}

		return issues;

	}

/////////////////////////////////////////////////////////////////////////////////////////
	public List<Issue> filterIssueByPriority(Priority priority, User user) {
		if (user.getRole() != Role.ISSUE_MANAGER) {
			throw new UnauthorizedIssueManagerException("Only users with ISSUE_MANAGER role can add issues");
		}
		List<Issue> issues = issueRepo.findByPriority(priority);
		if (issues.isEmpty()) {
			throw new IssueNotFoundException("No issues found with priority " + priority);
		}

		return issues;

	}

//////////////////////////////////////////////////////////////////////////////////////////////
	public Issue updateStatus(int issueId, User user, UpdateStatusDto dto) {
		Issue issue = getIssue(issueId);

		// Managers can update any issue.
		if (user.getRole() == Role.ISSUE_MANAGER) {
			issue.setStatus(dto.getUpdateStatus());
			issue.setUpdatedDate(LocalDateTime.now());
			return issueRepo.save(issue);
		}

		// Solvers can update only issues assigned to them.
		if (user.getRole() == Role.ISSUE_SOLVER) {
			if (issue.getAssignee() == null || !issue.getAssignee().equals(user.getEmail())) {
				throw new UnauthorizedIssueSolverException("You can update only issues assigned to you");
			}
		} else {
			throw new UnauthorizedIssueManagerException("Only manager and solver can update status");
		}

		issue.setStatus(dto.getUpdateStatus());
		issue.setUpdatedDate(LocalDateTime.now());

		return issueRepo.save(issue);
	}

////////////////////////////////////////////////////////////////////////////////
	@Transactional
	public Issue updateDetails(int issueId, User user, UpdateDetailDto dto) {

		Issue issue = getIssue(issueId); // fetch existing issue

		if (user.getRole() != Role.ISSUE_RAISER) {
			throw new UnauthorizedIssueManagerException("Only ISSUE_RAISER can update issues");
		}

		if (!issue.getUser().getId().equals(user.getId())) {
			throw new UnauthorizedIssueManagerException("You can update only your own issues");
		}

		if (dto.getTitle() == null || dto.getDescription() == null) {
			throw new RuntimeException("Title and description are required");
		}

		issue.setTitle(dto.getTitle());
		issue.setDescription(dto.getDescription());

		if (dto.getPriority() != null) {
			issue.setPriority(dto.getPriority());
		}

		return issueRepo.save(issue);
	}

////////////////////////////////////////////////////////////////////////////

	public List<Issue> getIssuesBySolverName(String solverName) {
		return issueRepo.findByAssignee(solverName);
	}
///////////////////////////////////////////////

	@Transactional
	public String deleteIssue(int issueId, User user) {

		if (user.getRole() == Role.ISSUE_MANAGER) {

			if (!issueRepo.existsById(issueId)) {
				throw new IssueNotFoundException("Issue not found");
			}

			issueRepo.deleteById(issueId);
			return "Issue deleted successfully";
		}

		if (user.getRole() == Role.ISSUE_RAISER) {

			Issue issue = issueRepo.findById(issueId).orElseThrow(() -> new IssueNotFoundException("Issue not found"));

			if (!issue.getUser().getId().equals(user.getId())) {
				throw new UnauthorizedIssueManagerException("You can delete only your own issues");
			}

			issueRepo.delete(issue);
			return "Issue deleted successfully";
		}

		throw new UnauthorizedIssueManagerException("You are not authorized to delete this issue");
	}

}
