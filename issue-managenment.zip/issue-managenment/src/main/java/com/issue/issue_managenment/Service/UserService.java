package com.issue.issue_managenment.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.issue.issue_managenment.DTO.UserSummaryDto;
import com.issue.issue_managenment.Entity.Role;
import com.issue.issue_managenment.Entity.User;
import com.issue.issue_managenment.Repo.UserRepo;

@Service
public class UserService {

	@Autowired
	UserRepo userRepo;

	public String signUp(User user) {
		Optional<User> existingUser = userRepo.findByEmail(user.getEmail());
		if (existingUser.isPresent()) {
			System.out.println("User already exists: " + existingUser.get().getEmail());
			throw new IllegalArgumentException("User with this email already exists");
		}
		userRepo.save(user);

		return "User signed up successfully";
	}

	public User login(String email, String password) {
		User user = userRepo.findByEmailAndPassword(email, password);
		if (user == null) {
			throw new IllegalArgumentException("Invalid email or password");
		}
		return user;
	}

	public List<UserSummaryDto> getSolvers() {
		List<User> solvers = userRepo.findByRole(Role.ISSUE_SOLVER);
		return solvers.stream()
				.map(u -> new UserSummaryDto(u.getId(), u.getName(), u.getEmail(), u.getRole()))
				.toList();
	}
}
