package com.issue.issue_managenment.DTO;

import com.issue.issue_managenment.Entity.Status;

public class UpdateStatusDto {

	private Status updateStatus;

	public UpdateStatusDto() {
		// TODO Auto-generated constructor stub
	}
	
	public UpdateStatusDto(Status updateStatus) {
		super();
		this.updateStatus = updateStatus;
	}

	public Status getUpdateStatus() {
		return updateStatus;
	}

	public void setUpdateStatus(Status updateStatus) {
		this.updateStatus = updateStatus;
	}

	

}
