package com.issue.issue_managenment.DTO;

public class AssignIssueRequest {
	private int managerId;
	private int solverId;
	private int issueId;

	// Getters and setters
	public int getManagerId() {
		return managerId;
	}

	public void setManagerId(int managerId) {
		this.managerId = managerId;
	}

	public int getSolverId() {
		return solverId;
	}

	public void setSolverId(int solverId) {
		this.solverId = solverId;
	}

	public int getIssueId() {
		return issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}
}
