package com.issue.issue_managenment.DTO;

import com.issue.issue_managenment.Entity.Priority;

import jakarta.validation.constraints.NotBlank;

public class UpdateDetailDto {

	@NotBlank
	private String title;
	@NotBlank
	private String description;
	@NotBlank
	private Priority priority;

	public UpdateDetailDto() {
		// TODO Auto-generated constructor stub
	}

	public UpdateDetailDto(String title, String description, Priority priority) {
		super();
		this.title = title;
		this.description = description;
		this.priority = priority;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

}
