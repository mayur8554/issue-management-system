package com.issue.issue_managenment.Exception;

public class UnauthorizedIssueRaiserException extends RuntimeException {
    public UnauthorizedIssueRaiserException(String message) {
        super(message);
    }
}