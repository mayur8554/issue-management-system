package com.issue.issue_managenment.Exception;

public class UnauthorizedIssueManagerException extends RuntimeException {
    public UnauthorizedIssueManagerException(String message) {
        super(message);
    }
}
