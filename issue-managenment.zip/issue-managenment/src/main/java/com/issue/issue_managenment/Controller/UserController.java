package com.issue.issue_managenment.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

import com.issue.issue_managenment.DTO.LoginDto;
import com.issue.issue_managenment.DTO.LoginResponseDto;
import com.issue.issue_managenment.DTO.UserSummaryDto;
import com.issue.issue_managenment.Entity.User;
import com.issue.issue_managenment.Repo.UserRepo;
import com.issue.issue_managenment.Service.UserService;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:4200")
public class UserController {

	@Autowired
	UserRepo userRepo;

	@Autowired
	UserService userService;

	@PostMapping("/signUp")
	public ResponseEntity<String> signUp(@RequestBody User user) {
		try {
			String message = userService.signUp(user);
			return ResponseEntity.status(HttpStatus.CREATED).body(message);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
		}
	}

	@PostMapping("/login")
	public ResponseEntity<LoginResponseDto> login(@RequestBody LoginDto loginDto) {
		try {
			User user = userService.login(loginDto.getEmail(), loginDto.getPassword());
			LoginResponseDto response = new LoginResponseDto(user.getId(), user.getName(), user.getEmail(),
					user.getRole());
			return ResponseEntity.ok(response);
		} catch (IllegalArgumentException e) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
		}
	}

	@GetMapping("/solvers")
	public ResponseEntity<List<UserSummaryDto>> getSolvers() {
		List<UserSummaryDto> solvers = userService.getSolvers();
		return ResponseEntity.ok(solvers);
	}

}
