package com.issue.issue_managenment.Entity;

public enum Role {
	
	ISSUE_RAISER,
	ISSUE_MANAGER,
	ISSUE_SOLVER

}
