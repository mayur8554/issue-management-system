package com.issue.issue_managenment.Exception;

public class UnauthorizedIssueSolverException extends RuntimeException {
    public UnauthorizedIssueSolverException(String message) {
        super(message);
    }
}
