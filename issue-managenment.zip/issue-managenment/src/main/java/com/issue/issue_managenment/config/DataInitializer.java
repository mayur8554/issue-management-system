package com.issue.issue_managenment.config;



import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.issue.issue_managenment.Entity.Role;
import com.issue.issue_managenment.Entity.User;
import com.issue.issue_managenment.Repo.UserRepo;

@Configuration
public class DataInitializer {

    @Bean
    CommandLineRunner initUsers(UserRepo userRepository) {
        return args -> {

            // Check if manager already exists
            Optional<User> managerCheck =
                    userRepository.findByEmail("rahul@example.com");

            if (managerCheck.isEmpty()) {

                // Create Manager
                User manager = new User();
                manager.setName("Rahul");
                manager.setEmail("rahul@example.com");
                manager.setPassword("password");
                manager.setRole(Role.ISSUE_MANAGER);
               // manager.setCreatedDate(LocalDateTime.now());
                userRepository.save(manager);

                // Create Solver 1
                User solver1 = new User();
                solver1.setName("Amit");
                solver1.setEmail("amit@example.com");
                solver1.setPassword("password");
                solver1.setRole(Role.ISSUE_SOLVER);
             //   solver1.setCreatedDate(LocalDateTime.now());
                solver1.setManager(manager);
                userRepository.save(solver1);

                // Create Solver 2
                User solver2 = new User();
                solver2.setName("Priya");
                solver2.setEmail("priya@example.com");
                solver2.setPassword("password");
                solver2.setRole(Role.ISSUE_SOLVER);
               // solver2.setCreatedDate(LocalDateTime.now());
                solver2.setManager(manager);
                userRepository.save(solver2);

                System.out.println("Default users created successfully!");
            }
        };
    }
}

