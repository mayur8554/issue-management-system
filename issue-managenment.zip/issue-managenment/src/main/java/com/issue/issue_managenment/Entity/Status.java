package com.issue.issue_managenment.Entity;

public enum Status {
	OPEN,
	IN_PROGRESS,
	RESOLVED,
	CLOSE
}
