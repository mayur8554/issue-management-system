package com.issue.issue_managenment.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.issue.issue_managenment.Entity.Issue;
import com.issue.issue_managenment.Entity.Priority;
import com.issue.issue_managenment.Entity.Status;

@Repository
public interface IssueRepo extends JpaRepository<Issue, Integer> {

	Issue findByIssueId(int id);

	List<Issue> findByStatus(Status status);

	List<Issue> findByPriority(Priority priority);

	List<Issue> findByUserId(int userId);

	List<Issue> findByAssignee(String assignee);

}
