package com.issue.issue_managenment.Exception;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler(IssueNotFoundException.class)
	public String handleIssueNotReceived(IssueNotFoundException msg) {
		return msg.getMessage();
		
	}
	
	
	@ExceptionHandler(UserNotFoundException.class)
	public String handleUserNotReceived(UserNotFoundException msg) {
		return msg.getMessage();
		
	}
	
	
	@ExceptionHandler(UnauthorizedIssueRaiserException.class)
	public String handleUnauthorizedIssueRaiser(UnauthorizedIssueRaiserException msg) {
		return msg.getMessage();
		
	}
	
	@ExceptionHandler(UnauthorizedIssueManagerException.class)
	public String handleUnauthorizedIssueManager(UnauthorizedIssueManagerException msg) {
		return msg.getMessage();
		
	}
	
	@ExceptionHandler(UnauthorizedIssueSolverException.class)
	public String handleUnauthorizedIssueSolver(UnauthorizedIssueSolverException msg) {
		return msg.getMessage();
		
	}

}
