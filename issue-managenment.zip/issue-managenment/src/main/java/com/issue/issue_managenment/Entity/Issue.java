package com.issue.issue_managenment.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "issue")
public class Issue {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "issue_Id")
	int issueId;

	@Column(name = "title")
	@NotBlank(message = "title is required")
	String title;

	@Column(name = "description")
	@NotBlank(message = "discription is required")
	String description;

	@Enumerated(EnumType.STRING)
	Priority priority;

	@Enumerated(EnumType.STRING)
	Status status;

	@CreationTimestamp
	@Column(name="created_date",updatable = false)
	LocalDateTime createdDate;

	@Column(name = "updated_Date")
	LocalDateTime updatedDate;

	@Column(name = "assignee")
	String assignee;
	
	
	@ManyToOne
	@JoinColumn(name = "user_Id")
	private User user;

	public Issue() {
		// TODO Auto-generated constructor stub
	}

	public Issue(String title, String description, Priority priority, Status status, String assignee) {
		super();
		this.title = title;
		this.description = description;
		this.priority = priority;
		this.status = status;
		this.assignee = null;
	}

	public int getIssueId() {
		return issueId;
	}

	public void setIssueId(int issueId) {
		this.issueId = issueId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String discription) {
		this.description = discription;
	}

	public Priority getPriority() {
		return priority;
	}

	public void setPriority(Priority priority) {
		this.priority = priority;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public LocalDateTime getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(LocalDateTime createdDate) {
		this.createdDate = createdDate;
	}

	public LocalDateTime getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(LocalDateTime localDateTime) {
		this.updatedDate = localDateTime;
	}

	public String getAssignee() {
		return assignee;
	}

	public void setAssignee(String assignee) {
		this.assignee = assignee;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

}
