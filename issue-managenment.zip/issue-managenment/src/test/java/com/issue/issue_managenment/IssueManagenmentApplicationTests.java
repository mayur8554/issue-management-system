package com.issue.issue_managenment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueManagenmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
