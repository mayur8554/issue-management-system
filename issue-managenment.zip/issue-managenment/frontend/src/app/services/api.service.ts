import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';

export type Role = 'ISSUE_RAISER' | 'ISSUE_SOLVER' | 'ISSUE_MANAGER';
export type Priority = 'LOW' | 'MEDIUM' | 'HIGH';
export type Status = 'OPEN' | 'IN_PROGRESS' | 'RESOLVED' | 'CLOSE';

export interface User {
  id?: number;
  name: string;
  email: string;
  password: string;
  role: Role;
}

export interface LoginResponse {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface UserSummary {
  id: number;
  name: string;
  email: string;
  role: Role;
}

export interface Issue {
  issueId?: number;
  title: string;
  description?: string;
  priority: Priority;
  status: Status;
  createdDate?: string;
  updatedDate?: string;
  assignee?: string;
  raiser?: string;
}

@Injectable({
  providedIn: 'root'
})
export class ApiService {
  private readonly baseUrl = 'http://localhost:8080';

  constructor(private readonly http: HttpClient) {}

  // Auth

  signUp(user: User): Observable<string> {
    return this.http.post(`${this.baseUrl}/user/signUp`, user, {
      responseType: 'text'
    });
  }

  login(email: string, password: string): Observable<LoginResponse> {
    return this.http.post<LoginResponse>(`${this.baseUrl}/user/login`, { email, password });
  }

  // Issues – Raiser & generic helpers

  addIssue(issue: Partial<Issue>, userId: number): Observable<Issue> {
    const params = new HttpParams().set('userId', userId);
    return this.http.post<Issue>(`${this.baseUrl}/issue/add`, issue, { params });
  }

  getUserIssues(userId: number): Observable<Issue[]> {
    const params = new HttpParams().set('userId', userId);
    return this.http.get<Issue[]>(`${this.baseUrl}/issue/viewUserIssue`, { params });
  }

  updateIssueDetails(issueId: number, userId: number, dto: { title: string; description: string; priority: Priority }): Observable<Issue> {
    const params = new HttpParams().set('issueId', issueId).set('userId', userId);
    return this.http.put<Issue>(`${this.baseUrl}/issue/updateDetails`, dto, { params });
  }

  deleteIssue(issueId: number, userId: number): Observable<string> {
    const params = new HttpParams().set('issueId', issueId).set('userId', userId);
    return this.http.delete(`${this.baseUrl}/issue/delete`, {
      params,
      responseType: 'text'
    });
  }

  // Manager

  getAllIssues(managerId: number): Observable<Issue[] | string> {
    const params = new HttpParams().set('userId', managerId);
    return this.http.get<Issue[] | string>(`${this.baseUrl}/issue/view`, { params });
  }

  filterIssuesByStatus(status: Status, managerId: number): Observable<Issue[]> {
    const params = new HttpParams().set('status', status).set('userId', managerId);
    return this.http.get<Issue[]>(`${this.baseUrl}/issue/filterStatus`, { params });
  }

  filterIssuesByPriority(priority: Priority, managerId: number): Observable<Issue[]> {
    const params = new HttpParams().set('priority', priority).set('userId', managerId);
    return this.http.get<Issue[]>(`${this.baseUrl}/issue/filterPriority`, { params });
  }

  getSolvers(): Observable<UserSummary[]> {
    return this.http.get<UserSummary[]>(`${this.baseUrl}/user/solvers`);
  }

  assignIssue(managerId: number, solverId: number, issueId: number): Observable<Issue> {
    return this.http.post<Issue>(`${this.baseUrl}/issue/assign`, {
      managerId,
      solverId,
      issueId
    });
  }

  // Solver

  getSolverIssues(assignee: string): Observable<Issue[]> {
    const params = new HttpParams().set('assignee', assignee);
    return this.http.get<Issue[]>(`${this.baseUrl}/issue/solverIssue`, { params });
  }

  updateStatus(issueId: number, userId: number, updateStatus: Status): Observable<Issue> {
    const params = new HttpParams().set('issueId', issueId).set('userId', userId);
    return this.http.put<Issue>(`${this.baseUrl}/issue/updateStatus`, { updateStatus }, { params });
  }
}

