import { Routes } from '@angular/router';
import { LoginComponent } from './auth/login.component';
import { SignupComponent } from './auth/signup.component';
import { RaiserDashboardComponent } from './dashboards/raiser-dashboard.component';
import { ManagerDashboardComponent } from './dashboards/manager-dashboard.component';
import { SolverDashboardComponent } from './dashboards/solver-dashboard.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'raiser', component: RaiserDashboardComponent },
  { path: 'manager', component: ManagerDashboardComponent },
  { path: 'solver', component: SolverDashboardComponent },
  { path: '**', redirectTo: 'login' }
];
