import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, Role, User } from '../services/api.service';

@Component({
  selector: 'app-signup',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './signup.component.html'
})
export class SignupComponent {
  model: Partial<User> = {
    name: '',
    email: '',
    password: '',
    role: 'ISSUE_RAISER'
  };

  loading = false;
  error?: string;
  message?: string;

  constructor(private readonly api: ApiService, private readonly router: Router) {}

  onSubmit(): void {
    this.error = undefined;
    this.message = undefined;

    if (!this.model.name || !this.model.email || !this.model.password || !this.model.role) {
      this.error = 'All fields are required.';
      return;
    }

    this.loading = true;
    this.api.signUp(this.model as User).subscribe({
      next: (msg) => {
        this.loading = false;
        this.message = msg;
        setTimeout(() => this.router.navigate(['/login']), 1200);
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error || 'Sign up failed';
      }
    });
  }
}

