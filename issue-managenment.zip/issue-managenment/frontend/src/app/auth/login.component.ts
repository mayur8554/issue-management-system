import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, LoginResponse, Role } from '../services/api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './login.component.html'
})
export class LoginComponent {
  email = '';
  password = '';
  role?: Role;

  loading = false;
  error?: string;
  message?: string;

  constructor(private readonly api: ApiService, private readonly router: Router) {}

  onSubmit(): void {
    this.error = undefined;
    this.message = undefined;

    if (!this.email || !this.password) {
      this.error = 'Email and password are required.';
      return;
    }

    this.loading = true;
    this.api.login(this.email, this.password).subscribe({
      next: (user: LoginResponse) => {
        this.loading = false;
        this.message = 'Login successful.';

        const target =
          user.role === 'ISSUE_MANAGER'
            ? '/manager'
            : user.role === 'ISSUE_SOLVER'
            ? '/solver'
            : '/raiser';

        this.router.navigate([target], {
          state: {
            userId: user.id,
            role: user.role,
            email: user.email
          }
        });
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error || 'Login failed';
      }
    });
  }
}

