import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, Issue, Priority, Status, UserSummary } from '../services/api.service';

@Component({
  selector: 'app-manager-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './manager-dashboard.component.html'
})
export class ManagerDashboardComponent {
  managerId?: number;
  email?: string;

  issues: Issue[] = [];
  solvers: UserSummary[] = [];
  loading = false;
  error?: string;
  message?: string;

  filterStatus?: Status;
  filterPriority?: Priority;
  readonly statuses: Status[] = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSE'];
  readonly priorities: Priority[] = ['LOW', 'MEDIUM', 'HIGH'];

  // Assign form
  assignSolverId?: number;
  assignIssueId?: number;

  constructor(private readonly api: ApiService, private readonly router: Router) {
    const nav = this.router.getCurrentNavigation();
    const state = (nav && nav.extras && nav.extras.state) as { userId?: number; email?: string } | undefined;
    if (state?.userId) {
      this.managerId = state.userId;
    }
    if (state?.email) {
      this.email = state.email;
    }

    if (this.managerId) {
      this.loadAll();
    }

    this.loadSolvers();
  }

  ensureManager(): boolean {
    if (!this.managerId) {
      this.error = 'Manager userId is required. Go back to login and provide it.';
      return false;
    }
    return true;
  }

  loadSolvers(): void {
    this.api.getSolvers().subscribe({
      next: (data) => {
        this.solvers = data;
      },
      error: () => {
        // silently ignore for now; assignment will still work with manual IDs if needed
      }
    });
  }

  loadAll(): void {
    if (!this.ensureManager()) {
      return;
    }
    this.loading = true;
    this.error = undefined;
    this.api.getAllIssues(this.managerId!).subscribe({
      next: (data: Issue[] | string) => {
        this.loading = false;
        if (typeof data === 'string') {
          this.message = data;
          this.issues = [];
        } else {
          this.issues = data;
        }
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error || 'Failed to load issues';
      }
    });
  }

  getSolverLabel(issue: Issue): string {
    if (!issue.assignee) {
      return '-';
    }
    const solver = this.solvers.find((s) => s.email === issue.assignee);
    if (solver) {
      return `${solver.name} (#${solver.id})`;
    }
    return issue.assignee;
  }

  applyFilter(): void {
    if (!this.ensureManager()) {
      return;
    }

    // Status filter takes precedence if set
    if (this.filterStatus) {
      this.loading = true;
      this.error = undefined;
      this.api.filterIssuesByStatus(this.filterStatus, this.managerId!).subscribe({
        next: (data) => {
          this.loading = false;
          this.issues = data;
        },
        error: (err) => {
          this.loading = false;
          this.error = err?.error || 'Failed to filter issues by status';
        }
      });
      return;
    }

    // Then try priority filter
    if (this.filterPriority) {
      this.loading = true;
      this.error = undefined;
      this.api.filterIssuesByPriority(this.filterPriority, this.managerId!).subscribe({
        next: (data) => {
          this.loading = false;
          this.issues = data;
        },
        error: (err) => {
          this.loading = false;
          this.error = err?.error || 'Failed to filter issues by priority';
        }
      });
      return;
    }

    // If no filters, just load all
    this.loadAll();
  }

  deleteIssue(issue: Issue): void {
    if (!this.ensureManager() || issue.issueId == null) {
      return;
    }
    if (!confirm('Delete issue #' + issue.issueId + '?')) {
      return;
    }
    this.api.deleteIssue(issue.issueId, this.managerId!).subscribe({
      next: (msg) => {
        this.message = msg;
        this.loadAll();
      },
      error: (err) => {
        this.error = err?.error || 'Failed to delete issue';
      }
    });
  }

  assign(): void {
    this.error = undefined;
    this.message = undefined;
    if (!this.managerId || !this.assignSolverId || !this.assignIssueId) {
      this.error = 'Manager ID, Solver ID and Issue ID are required for assignment.';
      return;
    }
    this.api.assignIssue(this.managerId, this.assignSolverId, this.assignIssueId).subscribe({
      next: (issue) => {
        this.message = `Issue #${issue.issueId} assigned successfully.`;
        this.loadAll();
      },
      error: (err) => {
        this.error = err?.error || 'Failed to assign issue';
      }
    });
  }
}

