import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, Issue, Priority, Status } from '../services/api.service';

@Component({
  selector: 'app-raiser-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './raiser-dashboard.component.html'
})
export class RaiserDashboardComponent {
  userId?: number;
  email?: string;

  newIssue: Partial<Issue> = {
    title: '',
    description: '',
    priority: 'LOW',
    status: 'OPEN'
  };

  editingIssue?: Issue;

  issues: Issue[] = [];
  statusFilter?: Status;
  priorityFilter?: Priority;
  loadingList = false;
  saving = false;
  error?: string;
  message?: string;

  readonly priorities: Priority[] = ['LOW', 'MEDIUM', 'HIGH'];
  readonly statuses: Status[] = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSE'];

  constructor(private readonly api: ApiService, private readonly router: Router) {
    const nav = this.router.getCurrentNavigation();
    const state = (nav && nav.extras && nav.extras.state) as { userId?: number; email?: string } | undefined;
    if (state?.userId) {
      this.userId = state.userId;
    }
    if (state?.email) {
      this.email = state.email;
    }

    if (this.userId) {
      this.loadIssues();
    }
  }

  get filteredIssues(): Issue[] {
    return this.issues.filter((issue) => {
      const statusOk = !this.statusFilter || issue.status === this.statusFilter;
      const priorityOk = !this.priorityFilter || issue.priority === this.priorityFilter;
      return statusOk && priorityOk;
    });
  }

  ensureUserId(): boolean {
    if (!this.userId) {
      this.error = 'User ID is required. Please log in again.';
      return false;
    }
    return true;
  }

  loadIssues(): void {
    if (!this.ensureUserId()) {
      return;
    }
    this.loadingList = true;
    this.error = undefined;
    this.api.getUserIssues(this.userId!).subscribe({
      next: (data) => {
        this.loadingList = false;
        this.issues = data;
      },
      error: (err) => {
        this.loadingList = false;
        this.error = err?.error || 'Failed to load issues';
      }
    });
  }

  createIssue(): void {
    if (!this.ensureUserId()) {
      return;
    }
    if (!this.newIssue.title || !this.newIssue.priority) {
      this.error = 'Title and priority are required.';
      return;
    }

    this.saving = true;
    this.error = undefined;
    this.api.addIssue(this.newIssue, this.userId!).subscribe({
      next: () => {
        this.saving = false;
        this.message = 'Issue created';
        this.newIssue = {
          title: '',
          description: '',
          priority: 'LOW',
          status: 'OPEN'
        };
        this.loadIssues();
      },
      error: (err) => {
        this.saving = false;
        this.error = err?.error || 'Failed to create issue';
      }
    });
  }

  startEdit(issue: Issue): void {
    this.editingIssue = { ...issue };
    this.message = undefined;
    this.error = undefined;
  }

  cancelEdit(): void {
    this.editingIssue = undefined;
  }

  saveEdit(): void {
    if (!this.ensureUserId() || !this.editingIssue || this.editingIssue.issueId == null) {
      return;
    }

    const payload = {
      title: this.editingIssue.title,
      description: this.editingIssue.description ?? '',
      priority: this.editingIssue.priority
    };

    this.saving = true;
    this.api.updateIssueDetails(this.editingIssue.issueId, this.userId!, payload).subscribe({
      next: () => {
        this.saving = false;
        this.message = 'Issue updated';
        this.editingIssue = undefined;
        this.loadIssues();
      },
      error: (err) => {
        this.saving = false;
        this.error = err?.error || 'Failed to update issue';
      }
    });
  }

  deleteIssue(issue: Issue): void {
    if (!this.ensureUserId() || issue.issueId == null) {
      return;
    }
    if (!confirm('Are you sure you want to delete this issue?')) {
      return;
    }
    this.api.deleteIssue(issue.issueId, this.userId!).subscribe({
      next: (msg) => {
        this.message = msg;
        this.loadIssues();
      },
      error: (err) => {
        this.error = err?.error || 'Failed to delete issue';
      }
    });
  }
}

