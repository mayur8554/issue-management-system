import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router, RouterModule } from '@angular/router';
import { ApiService, Issue, Status } from '../services/api.service';

@Component({
  selector: 'app-solver-dashboard',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterModule],
  templateUrl: './solver-dashboard.component.html'
})
export class SolverDashboardComponent {
  solverName?: string;
  solverId?: number;
  email?: string;

  issues: Issue[] = [];
  statusFilter?: Status;
  loading = false;
  error?: string;
  message?: string;

  readonly statuses: Status[] = ['OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSE'];

  selectedIssueIdForStatus?: number;
  selectedStatus?: Status;

  constructor(private readonly api: ApiService, private readonly router: Router) {
    const nav = this.router.getCurrentNavigation();
    const state = (nav && nav.extras && nav.extras.state) as
      | { userId?: number; email?: string }
      | undefined;
    if (state?.userId) {
      this.solverId = state.userId;
    }
    if (state?.email) {
      this.email = state.email;
      // Assignee in backend is stored as solver email
      this.solverName = state.email;
    }
  }

  get filteredIssues(): Issue[] {
    return this.issues.filter((issue) => !this.statusFilter || issue.status === this.statusFilter);
  }

  loadIssues(): void {
    if (!this.solverName) {
      this.error = 'Solver name (assignee) is required.';
      return;
    }
    this.loading = true;
    this.error = undefined;
    this.api.getSolverIssues(this.solverName).subscribe({
      next: (data) => {
        this.loading = false;
        this.issues = data;
      },
      error: (err) => {
        this.loading = false;
        this.error = err?.error || 'Failed to load assigned issues';
      }
    });
  }

  startUpdateStatus(issue: Issue): void {
    this.selectedIssueIdForStatus = issue.issueId;
    this.selectedStatus = issue.status;
  }

  updateStatus(): void {
    if (
      !this.selectedIssueIdForStatus ||
      !this.selectedStatus ||
      !this.solverId
    ) {
      this.error = 'Solver userId, issue and status are required.';
      return;
    }
    this.api
      .updateStatus(
        this.selectedIssueIdForStatus,
        this.solverId,
        this.selectedStatus
      )
      .subscribe({
        next: () => {
          this.message = 'Status updated.';
          this.selectedIssueIdForStatus = undefined;
          this.selectedStatus = undefined;
          this.loadIssues();
        },
        error: (err) => {
          this.error = err?.error || 'Failed to update status';
        }
      });
  }
}

